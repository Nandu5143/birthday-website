function checkBirthday() {
    const birthdayStr = "2025-08-15T00:00:00"; // YYYY-MM-DD format (Set your birthday here)
    const birthday = new Date(birthdayStr);
    const today = new Date();

    // If today is the birthday, go to the main page
    if (
        today.getDate() === birthday.getDate() &&
        today.getMonth() === birthday.getMonth()
    ) {
        window.location.href = "index.html";
        return;
    }

    // Else show countdown
    startCountdown(birthday);
}

function startCountdown(targetDate) {
    const message = document.getElementById("message");
    const interval = setInterval(() => {
        const now = new Date().getTime();
        const distance = targetDate.getTime() - now;

        if (distance <= 0) {
            clearInterval(interval);
            message.innerText = "🎉 It's your birthday! Refresh to celebrate!";
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor(
            (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
        );
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        message.innerText = `⏳ Your birthday is in ${days}d ${hours}h ${minutes}m ${seconds}s`;
    }, 1000);
}
